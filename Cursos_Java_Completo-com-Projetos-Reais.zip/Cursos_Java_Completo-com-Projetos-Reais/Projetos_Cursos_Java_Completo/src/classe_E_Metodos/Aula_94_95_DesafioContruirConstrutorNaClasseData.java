package classe_E_Metodos;

public class Aula_94_95_DesafioContruirConstrutorNaClasseData {

	//Acrscentar o construtor na classe data: definir de forma explicita o construtor  
	//padr�o e definir o contrutor que vai receber dia, mes e ano
	//quando for chamar o contrutor padr�o ir� imrpimir a data 01 01 1970
	//quando for chamar o construtor explicito ir� apresentar o dia, mes e ano que foi inserido.
	public static void main(String[] args) {
		

	}

}
