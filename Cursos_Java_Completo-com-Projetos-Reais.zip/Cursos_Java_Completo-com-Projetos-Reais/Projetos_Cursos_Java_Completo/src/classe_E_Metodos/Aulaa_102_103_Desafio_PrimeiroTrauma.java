package classe_E_Metodos;

public class Aulaa_102_103_Desafio_PrimeiroTrauma {
	
	int a =  3; //n�o pode mecher nessa linha. 

	static int r =  6;
	public static void main(String[] args) {
		
		Aulaa_102_103_Desafio_PrimeiroTrauma b = new Aulaa_102_103_Desafio_PrimeiroTrauma();
		
		System.out.println(b.a);
		System.out.println(r);

	}

}
