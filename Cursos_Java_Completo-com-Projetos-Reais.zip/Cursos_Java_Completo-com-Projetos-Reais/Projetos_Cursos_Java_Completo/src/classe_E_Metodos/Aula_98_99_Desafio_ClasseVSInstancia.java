package classe_E_Metodos;

public class Aula_98_99_Desafio_ClasseVSInstancia {

	
	//Criar uma classe que o desconto seja de 25% de desconto para todos os produtos.
	//colocar o desconto como uma variavel de classe "Static".
	//o valor dod desconto � de 0.25 de desconto.
	
	String nome;
	double preco;
	static double desconto; // continuar......
	
	
	
	
	
	public static void main(String[] args) {
	

	}

}
