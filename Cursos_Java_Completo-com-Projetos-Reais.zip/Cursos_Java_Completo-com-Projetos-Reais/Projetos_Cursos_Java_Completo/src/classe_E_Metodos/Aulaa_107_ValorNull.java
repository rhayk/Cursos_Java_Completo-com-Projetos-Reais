package classe_E_Metodos;

public class Aulaa_107_ValorNull {

	public static void main(String[] args) {
		String s1 = "";
		
		System.out.println("!!!");
		
		
		//Quando a intancia e referenciada com null ela perde o valor e a memoria.
		//isso gera um erro.....
		//EX:
//		Aulaa_104_This_This d = null;
//		d.nome = "aa";
//		System.out.println(d.nome);
		

//     CORRE��O DO ERRO --> fazer uma condi��o para a execu��o do codigo;
//		
//	Aulaa_104_This_This d = null;
//	
//	if(d != null) {
//	d.nome = "aa";
//	}
//	System.out.println(d.nome);
		
		
		

	}

}
