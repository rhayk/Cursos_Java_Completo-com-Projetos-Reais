package classe_E_Metodos;

public class Aula_85_Class_E_Produto {

		String nome;
		double preco;
		double desconto;
		
		
	

	

}
