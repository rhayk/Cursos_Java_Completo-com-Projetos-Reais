package classe_E_Metodos;

public class Aula_86_87_Desafio {
	//Desafio - > criar a classe data com 3 atributos (dia, mes e ano)
	//Instaciar o dia o mes e o ano na classe teste.
	

}
