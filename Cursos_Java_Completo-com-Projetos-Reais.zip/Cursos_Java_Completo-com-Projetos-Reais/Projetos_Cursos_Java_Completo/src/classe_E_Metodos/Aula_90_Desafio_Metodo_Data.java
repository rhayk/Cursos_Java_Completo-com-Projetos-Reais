package classe_E_Metodos;

public class Aula_90_Desafio_Metodo_Data {
	//Desafio retorna dia, mes e ano formatado na classe data do outro desfio.

	int dia;
	int mes;
	int ano;
	
	void obterdataFormatada() { //definir o tipo de retorno......void ^^
		
	}
}
