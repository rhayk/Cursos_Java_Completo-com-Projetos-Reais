package estruturaDeControle;

public class Aula_56e57_DesafioIF {

	public static void main(String[] args) {
		double nota = 1.3;
		
		if(nota >= 9.0); { //O ponto e a virgula e erro do c�digo, ent�o por isso que ele imprimi.
			//Essa express�o � falsa, n�o � pra immprimir nada.
			System.out.println("Quado de Honra!");
			System.out.println("Voc� � fera!!!");
			
			System.out.println("=================================");
			
			if(nota >= 8.0) { //N�o usar o ponto � virgula ";" em esstrutuas de controle(tem uma exce��o)
				System.out.println("Quado de Honra!");
				System.out.println("Voc� � fera!!!");
		}

	}

	}
}
