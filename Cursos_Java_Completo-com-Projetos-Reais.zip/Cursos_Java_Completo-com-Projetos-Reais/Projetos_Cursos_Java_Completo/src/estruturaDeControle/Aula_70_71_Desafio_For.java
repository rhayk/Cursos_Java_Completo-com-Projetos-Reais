package estruturaDeControle;

public class Aula_70_71_Desafio_For {

	public static void main(String[] args) {
	String valor = "#";
	
	for(int i = 1;i <= 5; i++) {
		System.out.println(valor);
		valor += "#";
	}
	//vers�o do desafio
	//N�o pode usar valor num�rico pra controlar o la�o.

	}

}
