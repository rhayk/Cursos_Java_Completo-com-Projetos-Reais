package estruturaDeControle;

public class Aula_63_For {

	public static void main(String[] args) {
		
		//for com uma estrutura determinada
		
		//declara��o da variavel, express�o que vai retornar verdadeiro ou falso e incremento
	for(int contador = 1; contador <= 10; contador++) {
		System.out.printf("Aprendendo a contar: %d\n", contador);
	}

	}

}
