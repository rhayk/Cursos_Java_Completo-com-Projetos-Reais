package estruturaDeControle;

public class Aula_77_78_79 {


//============excercicios============
//		Estruturas de Controle
//
//		1. Criar um programa que receba um número e verifique se ele está entre 0 e 10 e é par;
//
//		2. Criar um programa informa se o ano atual é um ano bissexto;
//
//		3. Criar um programa que receba duas notas parciais, calcular a média final. Se a nota do aluno for maior ou igual a 7.0 imprime no console "Aprovado", se a nota for menor que 7.0 e maior do que 4.0 imprime no console "Recuperação", caso contrário imprime no console "Reprovado".
//
//		4. Criar um programa que receba um número e diga se ele é um número primo.
//
//		5. Refatorar o exercício 04, utilizando a estrutura switch.
//
//		6. Jogo da adivinhação: Tentar adivinhar um número entre 0 - 100. Armazene um numero aleatório em uma variável. O Jogador tem 10 tentativas para adivinhar o número gerado. Ao final de cada tentativa, imprima a quantidade de tentativas restantes, e imprima se o número inserido é maior ou menor do que o número armazenado.
//
//		7. Criar um programa que enquanto estiver recebendo números positivos, imprime no console a soma dos números inseridos, caso receba um número negativo, encerre o programa. Tente utilizar a estrutura do while.
//
//		8. Criar um programa que receba uma palavra e imprime no console letra por letra.
//
//		9. Crie um programa que recebe 10 valores e ao final imprima o maior número.
	
}
