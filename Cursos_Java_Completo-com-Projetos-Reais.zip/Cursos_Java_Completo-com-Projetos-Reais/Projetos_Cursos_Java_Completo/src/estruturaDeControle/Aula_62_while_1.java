package estruturaDeControle;

public class Aula_62_while_1 {

	//aprendendo a utilizar o contador no while
	public static void main(String[] args) {
	int contador = 1;
	//Esse se caracteriza em um While determinante -> j� est� definido a cantidade de repeti��o. 
	while(contador <= 10) {
		System.out.printf("Bora aprender a contar: %d\n", contador); //utilizando a variavel para imprimir a contagem
		contador++;
	}

	}

}
