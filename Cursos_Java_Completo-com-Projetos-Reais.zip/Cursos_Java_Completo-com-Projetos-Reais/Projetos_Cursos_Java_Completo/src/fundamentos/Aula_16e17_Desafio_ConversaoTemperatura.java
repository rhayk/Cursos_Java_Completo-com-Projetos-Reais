package fundamentos;

public class Aula_16e17_Desafio_ConversaoTemperatura {

		// DESAFIO -> Como transformar temperatura Fahrenheit em Celsius?
		// Contadores para armazenamento em ° 32 eon ° 5/9
		// Duas variáveis ​​para armazenar a temperatura em "° F" e o resultado em "° C"
		public  static  void  main ( String [] args ) {
			

		}

	}


