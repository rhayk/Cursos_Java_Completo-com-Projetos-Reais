package fundamentos;

public class Aula_50e51_DesafioDoModulo_Calculadora {

	public static void main(String[] args) {
		//Ler num1 do terminal do usu�rio
		//Ler num2 do terminal do usu�rio
		//Pedir para o usu�rio digitar a opera��o(+, -, *, /, %)
		//fazer a opera��o do num1 com o num2
		//E imprimir o resutado no terminal
		
	}

}
