package fundamentos;

public class Aula_36e37_DesafioAritmeticos {

	public static void main(String[] args) {
		
		//pr�-requisito para o desafio "math.pow"
		int a = 3 * 4 - 10;
		int b = (int) Math.pow(a, 3);
		System.out.println(b);

	}

}

