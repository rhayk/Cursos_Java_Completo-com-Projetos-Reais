package fundamentos;

public class Aula_27e28_ConversaoDeTiposPrimitivos {

	public static void main(String[] args) {
		
		//Convers�o impl�cita
		double a = 1;
		System.out.println(a);
		
		//conversao expl�cita "Cast"
		float b = (float)1.82;
		System.out.println(b);
		
		int c = 4;
		byte d = (byte)c; //convers�o expl�cta "Cast"
		System.out.println(d);
	}
}
