package fundamentos;

public class Aula_48e49_JREEeJDK {

	public static void main(String[] args) {
	System.out.println("JRE � o java runtime ou seja m�quina virtual java -> � utilizado para usu�rio");
	
	System.out.println("JDK -> � o kit para desenvolvimento ele tem o JRE nele ");
	
	System.out.println("JVM -> Faz a convers�o do c�digo natural para a linguagem da m�quina (bytecode), "
			+ "o bytecode ser� o c�digo para execu��o"
			+ "");

	}

}
