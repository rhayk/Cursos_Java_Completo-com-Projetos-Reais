package fundamentos;

import java.util.Date;



public class Aula_22_Import {
	public static void main(String[] args) {
		
		//Ficar atendo nos import para n�o importa os de outras classes.
		// Ctrl + shift + o = elimina os impots desnecess�rios e importa os que est�o faltando.
		String s = "Bom dia!";
		System.out.println(s);

		Date d = new Date();
		System.out.println(d);

		
		
	}
}
