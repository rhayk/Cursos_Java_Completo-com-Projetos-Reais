package fundamentos;

public class Aula_18_Inferencia_Tipos {

	public static void main(String[] args) {
		//variaveis s�o fortemente tipados, ou seja os tipos n�o se alteram.
		//Obrigat�riedade voc� precisa declarar um tipo de variaveis
		double a = 4.5;
		System.out.println(a);
		
		// o tipo "var" est� dispon�vel a partir do java 10.
		
		double d;
		d = 134.45;
		System.out.println(d);

	}

}
