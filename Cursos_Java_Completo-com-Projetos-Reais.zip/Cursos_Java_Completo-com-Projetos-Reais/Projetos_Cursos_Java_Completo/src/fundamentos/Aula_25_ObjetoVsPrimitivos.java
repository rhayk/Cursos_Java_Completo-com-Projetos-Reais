package fundamentos;

public class Aula_25_ObjetoVsPrimitivos {

	public static void main(String[] args) {
		
		String s = new String ("texto");
		s.toUpperCase();
		
		//Tudo em java s�o objetos menos os 8 tipos primitivos
		
		
		//Wrappers s�o a vers�o objeto dos tipos primitivos!
		int a = 123;
		System.out.println(a);
		
		

	}

}
