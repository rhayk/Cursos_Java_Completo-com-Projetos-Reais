package fundamentos;

public class Aula_33e34_Operaddores {

	public static void main(String[] args) {
//			Operadores: Aritmeticos, Relacionais, l�gicos, Atribui��o
//           Un�rios / Bin�rios / Tern�rios
//				a++  / 3+2      / v ? v : v
		
//       (+A) -> PREFIX         (A+) -> POSTFIX       (A+A) -> INFIX


	}

}
