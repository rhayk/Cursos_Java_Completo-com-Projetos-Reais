package fundamentos;

public class Aula_31e32_Conversao {

	public static void main(String[] args) {
	// Desafio convers�o: 
		//criar uma classe chamada desafioConvers�o
		//Importa o a classe scanner e criar 3 strings usando nextLine"Pega a linha toda" ou next"Pega uma �nica palavra"
		// as 3 strings v�o receber os 3 sal�rio de um funcion�rios
		//***usar  "," ou "." para separar as casas decimais
		//Somar os 3 sal�rios e dividir por 3 e tirar a m�dia
		//conveter uma string em um valor numerico

	}

}
